import type { Metadata } from "next";
import Script from "next/script";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { APP_NAME, BASE_URL, contactInfo } from "@/lib/config";
import { blogPosts, getBlogBySlug, getRelatedPosts, getPrevNextPosts, getPostCategories } from "@/lib/blog-data";
import { BlogSidebar } from "@/app/component/BlogSidebar";
import { FaqSection } from "@/app/component/FaqSection";

interface BlogDetailPageProps {
  params: Promise<{ slug: string }>;
}

// Generate static params for all blog posts
export async function generateStaticParams() {
  return blogPosts.map((post) => ({
    slug: post.slug,
  }));
}

// Generate metadata dynamically
export async function generateMetadata({ params }: BlogDetailPageProps): Promise<Metadata> {
  const { slug } = await params;
  const post = getBlogBySlug(slug);
  
  if (!post) {
    return {
      title: "Post Not Found",
    };
  }

  return {
    title: `${post.title} | Blog | ${APP_NAME}`,
    description: post.excerpt,
    keywords: post.keywords,
    authors: [{ name: post.author.name }],
    alternates: {
      canonical: `${BASE_URL}/blog/${post.slug}`,
    },
    openGraph: {
      title: `${post.title} | Blog | ${APP_NAME}`,
      description: post.excerpt,
      url: `${BASE_URL}/blog/${post.slug}`,
      type: "article",
      siteName: `${APP_NAME}`,
      locale: "en",
      publishedTime: `${post.publishedAt}`,
      authors: [`${post.author.name}`],
      section: `${post.category}`,
      images: [
        {
          url: `${BASE_URL}/${post.coverImage}`,
          width: 1200,
          height: 630,
          alt: post.title,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      site: `${BASE_URL}`,
      creator: `${APP_NAME}`,
      title: `${post.title} | Blog | ${APP_NAME}`,
      description: post.excerpt,
      images: `${BASE_URL}/${post.coverImage}`,
    },
  };
}

export default async function BlogDetailPage({ params }: BlogDetailPageProps) {
  const { slug } = await params;
  const post = getBlogBySlug(slug);

  if (!post) {
    notFound();
  }

  const relatedPosts = getRelatedPosts(slug, 3);
  const { prev: prevPost, next: nextPost } = getPrevNextPosts(slug);
  const faqItems = (post.faq ?? []).map((faq, i) => ({
    title: faq.question,
    content: faq.answer,
  }));

  const schemaData = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "BlogPosting",
        "@id": `${BASE_URL}/blog/${post.slug}/#BlogPosting`,
        "mainEntityOfPage": {
          "@type": "WebPage",
          "@id": `${BASE_URL}/blog/${post.slug}/#BlogPage`
        },
        "headline": `${post.title} | Blog | ${APP_NAME}`,
        "description": `${post.excerpt}`,
        "image": {
          "@type": "ImageObject",
          "url": `${BASE_URL}/${post.coverImage}`,
          "width": 1200,
          "height": 630
        },
        "datePublished": `${post.publishedAt}`,
        "author": {
          "@type": "Person",
          "name": `${post.author.name}`,
          "jobTitle": `${post.author.role}`,
          "image": `${BASE_URL}/${post.author.avatar}`
        },
        "publisher": {
          "@type": "Organization",
          "name": `${APP_NAME}`,
          "logo": {
            "@type": "ImageObject",
            "url": `${BASE_URL}${contactInfo.logo}`
          }
        },
        "articleSection": `${post.category}`,
        "keywords": `${post.keywords}`,
        "wordCount": `${post.content.split(/\s+/).length}`,
        "inLanguage": "en"
      },
      {
        "@type": "WebPage",
        "@id": `${BASE_URL}/blog/${post.slug}/#BlogPage`,
        "url": `${BASE_URL}/blog/${post.slug}`,
        "name": `${post.title} | Blog | ${APP_NAME}`,
        "isPartOf": {
          "@id": `${BASE_URL}/blog/#WebPage`  
        },
        "primaryImageOfPage": {
          "@type": "ImageObject",
          "url": `${BASE_URL}/${post.coverImage}`
        },
        "datePublished": `${post.publishedAt}`,
        "dateModified": `${post.publishedAt}`,
        "description": `${post.excerpt}`
      },
      {
        "@type": "BreadcrumbList",
        "itemListElement": [
          {
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": `${BASE_URL}`
          },
          {
            "@type": "ListItem",
            "position": 2,
            "name": "Blog",
            "item": `${BASE_URL}/blog`
          },
          {
            "@type": "ListItem",
            "position": 3,
            "name": post.title,
            "item": `${BASE_URL}/blog/${post.slug}`
          }
        ]
      },
      {
        "@type": "FAQPage",
        "@id": `${BASE_URL}/blog/${post.slug}/#FAQPage`,
        "mainEntity": [
          ...faqItems.map((faq, i) => ({
            "@type": "Question",
            "name": `${faq.title}`,
            "acceptedAnswer": {
              "@type": "Answer",
              "text": `${faq.content}`
            }
          })),
        ]
      }
    ]
  };

  return (
    <>
      {/* Structured Data */}
      <Script id="blog-detail-schema" type="application/ld+json" strategy="beforeInteractive" dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData, null,  2) }} />

      <section className="relative pt-12 pb-8">
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute top-10 left-10 w-72 h-72 bg-indigo-400/15 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-emerald-300/10 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-wrap items-center justify-center gap-3">
            {getPostCategories(post).map((category) => (
              <Link key={category} href={`/blog?category=${encodeURIComponent(category)}`} className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-blue-500 text-white rounded-xl hover:shadow-lg transition-shadow">{category}</Link>
            ))}
            <span className="text-neutral-500">Published on: {new Date(post.publishedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-neutral-900 text-center">{post.title}</h1>
          <div className="relative w-full rounded-xl overflow-hidden">
            <Image src={`/${post.coverImage}`} alt={post.title} width={1000} height={500} className="object-cover" priority />
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="relative py-12 lg:py-16">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 right-10 w-72 h-72 bg-indigo-400/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-emerald-300/10 rounded-full blur-3xl" />
        </div>
        <div className="relative z-10 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <article className="lg:col-span-8">
              
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="blog-content space-y-4" dangerouslySetInnerHTML={{ __html: post.content }} />
              </div>

              <div className="mt-10 p-6 bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl">
                <div className="flex flex-col sm:flex-row items-start gap-6">
                  <div className="relative w-20 h-20 rounded-full overflow-hidden flex-shrink-0">
                    <Image src={`/${post.author.avatar}`} alt={post.author.name} fill className="object-cover" />
                  </div>
                  <div className="space-y-1">
                    <div className="text-xs font-semibold text-indigo-600 uppercase tracking-widest">Written by</div>
                    <div className="font-semibold text-neutral-900">{post.author.name}</div>
                    <div className="text-neutral-500 text-sm">{post.author.role} at {APP_NAME}</div>
                  </div>
                </div>
              </div>

              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6">
                {prevPost ? (
                  <Link href={`/blog/${prevPost.slug}`} className="group flex items-center gap-4 p-5 bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                    <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-neutral-100 group-hover:bg-indigo-100 flex items-center justify-center transition-colors duration-200">
                      <svg className="w-5 h-5 text-neutral-500 group-hover:text-indigo-600 transition-colors group-hover:-translate-x-0.5 duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </div>
                    <div className="flex-1">
                      <div className="text-xs font-medium text-neutral-500 uppercase tracking-wider mb-1">Previous</div>
                      <p className="font-semibold text-neutral-900 group-hover:text-indigo-600">{prevPost.title}</p>
                    </div>
                  </Link>
                ) : (
                  <Link href="/blog" className="group flex items-center gap-4 p-5 bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                    <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-neutral-100 group-hover:bg-indigo-100 flex items-center justify-center transition-colors duration-200">
                      <svg className="w-5 h-5 text-neutral-500 group-hover:text-indigo-600 transition-colors group-hover:-translate-x-0.5 duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                      </svg>
                    </div>
                    <div className="flex-1">
                      <div className="text-xs font-medium text-neutral-500 uppercase tracking-wider">Back to</div>
                      <p className="font-semibold text-neutral-900 group-hover:text-indigo-600">All Articles</p>
                    </div>
                  </Link>
                )}

                {nextPost ? (
                  <Link href={`/blog/${nextPost.slug}`} className="group flex items-center gap-4 p-5 bg-gradient-to-r from-indigo-600 to-blue-500 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 text-white">
                    <div className="flex-1 text-right">
                      <div className="text-xs font-medium text-white/70 uppercase tracking-wider">Next</div>
                      <p className="font-semibold text-white">{nextPost.title}</p>
                    </div>
                    <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                      <svg className="w-5 h-5 text-white group-hover:translate-x-0.5 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </Link>
                ) : (
                  <Link href="/blog" className="group flex items-center gap-4 p-5 bg-gradient-to-r from-indigo-600 to-blue-500 rounded-2xl shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-1 text-white">
                    <div className="flex-1 text-right">
                      <div className="text-xs font-medium text-white/70 uppercase tracking-wider">Explore</div>
                      <p className="font-semibold text-white">More Articles</p>
                    </div>
                    <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
                      <svg className="w-5 h-5 text-white group-hover:translate-x-0.5 transition-transform duration-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                      </svg>
                    </div>
                  </Link>
                )}
              </div>
              
              {faqItems.length > 0 && (
                <div className="mt-10">
                  <h2 className="text-2xl font-bold text-neutral-900 mb-4">Frequently Asked Questions</h2>
                  <FaqSection items={faqItems} />
                </div>
              )}
              
            </article>
            <div className="lg:col-span-4">
              <div className="lg:sticky lg:top-8">
                <BlogSidebar currentPostSlug={post.slug} relatedPosts={relatedPosts} />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}