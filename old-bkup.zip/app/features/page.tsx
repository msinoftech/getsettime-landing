import type { Metadata } from "next";
import Link from "next/link";
import { APP_NAME, BASE_URL, LOGIN_URL, REGISTER_GOOGLE_URL, contactInfo } from "@/lib/config";
import Heading from "../component/Heading";
import Card from "../component/Card";
import CheckList from "../component/CheckList";
// import FeaturesSection from "../component/Features";

export const metadata: Metadata = {
  title: `Features | ${APP_NAME}`,
  description: `Explore ${APP_NAME} features: online booking, WhatsApp reminders, Google Calendar sync, staff scheduling, queue management, reporting, and more for clinics, salons, and service businesses.`,
  keywords: [
    "appointment scheduling features",
    "WhatsApp booking reminders",
    "Google Calendar sync",
    "staff scheduling software",
    "online appointment booking",
  ],
  alternates: {
    canonical: `${BASE_URL}/features`,
  },
  openGraph: {
    title: `Features | ${APP_NAME}`,
    description: `Smart scheduling features for doctors, clinics, salons, and service professionals — bookings, reminders, calendar sync, and team management in one place.`,
    url: `${BASE_URL}/features`,
    type: "website",
    siteName: APP_NAME,
    locale: "en",
    images: [
      {
        url: `${BASE_URL}${contactInfo.logo}`,
        width: 500,
        height: 500,
        alt: `${APP_NAME} features`,
      },
    ],
  },
};

const heroHighlights = [
    "Plans from ₹999/month",
    "250 bookings/month on Starter",
    "Built for clinics, salons & services",
];

const schedule = [
    { time: "09:00", period: "AM", title: "Dental Consultation", meta: "Dr. Sharma • Room 2", status: "Confirmed", tone: "indigo" },
    { time: "11:30", period: "AM", title: "Hair Treatment", meta: "Aisha • Salon Desk", status: "Paid", tone: "emerald" },
    { time: "02:00", period: "PM", title: "Physio Session", meta: "Ravi • Studio 1", status: "Online", tone: "slate" },
];

const featureSuiteCards = [
  {
    badge: "Booking",
    title: "Online booking engine",
    description: "Create branded booking experiences for services, departments, providers, locations and event types.",
    bullets: ["Custom availability rules", "Buffer times and capacity", "Reschedule and cancel flows"],
    icon: (
      <svg width="25" height="25" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M8 7V3m8 4V3M5 11h14M7 21h10a3 3 0 0 0 3-3V7a3 3 0 0 0-3-3H7a3 3 0 0 0-3 3v11a3 3 0 0 0 3 3Z" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
      </svg>
    ),
    iconWrapperClassName: "grid h-14 w-14 place-items-center rounded-2xl bg-indigo-50 text-indigo-600",
  },
  {
    badge: "Reminder",
    title: "WhatsApp automation",
    description: "Send booking confirmations, reminders, reschedule links and follow-ups without manual staff work.",
    bullets: ["Instant confirmation", "Reminder sequences", "Real-time customer updates"],
    icon: (
      <svg width="25" height="25" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M7.5 19.5 4 20.5l1-3.2A8 8 0 1 1 7.5 19.5Z" stroke="currentColor" strokeWidth={2} />
        <path d="M8 10h8M8 14h5" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
      </svg>
    ),
    iconWrapperClassName: "grid h-14 w-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-700",
  },
  {
    badge: "Team",
    title: "Provider management",
    description: "Manage staff calendars, roles, working hours, leave days, rooms, resources and service assignments.",
    bullets: ["Provider availability", "Department/service mapping", "Multi-location scheduling"],
    icon: (
      <svg width="25" height="25" viewBox="0 0 24 24" fill="none" aria-hidden>
        <path d="M16 11a4 4 0 1 0-8 0v7h8v-7Z" stroke="currentColor" strokeWidth={2} />
        <path d="M6 21h12M9 6V3h6v3" stroke="currentColor" strokeWidth={2} strokeLinecap="round" />
      </svg>
    ),
    iconWrapperClassName: "grid h-14 w-14 place-items-center rounded-2xl bg-blue-50 text-blue-600",
  },
];

const workflowSteps = [
  {
    step: 1,
    tag: "Book",
    title: "Customer books a slot",
    description: "Online booking page validates availability, service rules, provider and branch.",
    accentBar: "bg-gradient-to-b from-indigo-500 to-violet-500",
    iconWrap: "bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-lg shadow-indigo-200",
    icon: (
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
      </svg>
    ),
  },
  {
    step: 2,
    tag: "Sync",
    title: "Calendar and team update",
    description: "Staff schedule, internal dashboard and Google Calendar stay synchronized.",
    accentBar: "bg-gradient-to-b from-violet-500 to-purple-500",
    iconWrap: "bg-gradient-to-br from-violet-500 to-purple-600 text-white shadow-lg shadow-violet-200",
    icon: (
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
      </svg>
    ),
  },
  {
    step: 3,
    tag: "Notify",
    title: "WhatsApp reminders trigger",
    description: "Customers get confirmation, reminders and reschedule links automatically.",
    accentBar: "bg-gradient-to-b from-emerald-500 to-green-500",
    iconWrap: "bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-lg shadow-emerald-200",
    icon: (
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
      </svg>
    ),
  },
  {
    step: 4,
    tag: "Retain",
    title: "Follow-up grows retention",
    description: "Review requests, rebooking prompts and customer notes keep relationships warm.",
    accentBar: "bg-gradient-to-b from-cyan-500 to-sky-500",
    iconWrap: "bg-gradient-to-br from-cyan-500 to-sky-600 text-white shadow-lg shadow-cyan-200",
    icon: (
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
      </svg>
    ),
  },
];

const industryCards = [
  {
    badge: "Clinics",
    title: "Reduce front-desk load",
    description: "Let patients book, reschedule and receive reminders without repeated calls.",
    href: "/solutions/doctor-appointment-scheduling-software",
    featured: false,
    gradient: "from-indigo-500/10 via-transparent to-transparent",
    iconWrap: "bg-indigo-100 text-indigo-600 ring-indigo-200/60",
    icon: (
      <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
      </svg>
    ),
  },
  {
    badge: "Salons",
    title: "Fill staff calendars",
    description: "Manage providers, services, durations, payments and reminders from one screen.",
    href: "/solutions/salon-appointment-scheduling-software",
    featured: true,
    gradient: "from-violet-500/15 via-indigo-500/5 to-transparent",
    iconWrap: "bg-violet-100 text-violet-600 ring-violet-200/60",
    icon: (
      <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
      </svg>
    ),
  },
  {
    badge: "Services",
    title: "Scale operations",
    description: "Coordinate teams, locations, booking rules and customer communication smoothly.",
    href: "/solutions/physiotherapist-appointment-booking-software",
    featured: false,
    gradient: "from-emerald-500/10 via-transparent to-transparent",
    iconWrap: "bg-emerald-100 text-emerald-600 ring-emerald-200/60",
    icon: (
      <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
  },
];

const weeklyBookings = [
  { day: "Mon", bookings: 32 },
  { day: "Tue", bookings: 41 },
  { day: "Wed", bookings: 38 },
  { day: "Thu", bookings: 58 },
  { day: "Fri", bookings: 47 },
  { day: "Sat", bookings: 62 },
  { day: "Sun", bookings: 34 },
] as const;

const bookingChart = (() => {
  const width = 400;
  const height = 168;
  const pad = { top: 18, right: 14, bottom: 34, left: 42 };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;
  const max = Math.max(...weeklyBookings.map((d) => d.bookings));
  const total = weeklyBookings.reduce((sum, d) => sum + d.bookings, 0);
  const points = weeklyBookings.map((d, i) => ({
    ...d,
    x: pad.left + (i / (weeklyBookings.length - 1)) * plotW,
    y: pad.top + plotH - (d.bookings / max) * plotH,
  }));
  const linePath = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");
  const areaPath = `${linePath} L${points[points.length - 1].x.toFixed(1)},${(pad.top + plotH).toFixed(1)} L${points[0].x.toFixed(1)},${(pad.top + plotH).toFixed(1)} Z`;
  const yTicks = [0, 0.25, 0.5, 0.75, 1].map((t) => ({
    y: pad.top + plotH * (1 - t),
    label: Math.round(max * t),
  }));
  return { width, height, pad, plotH, max, total, points, linePath, areaPath, yTicks };
})();

const analyticsMetrics = [
  {
    label: "Revenue",
    value: "₹1.2L",
    change: "+12% this week",
    changeClassName: "text-emerald-700 bg-emerald-50",
    cardClassName: "border-violet-100 bg-gradient-to-br from-violet-50/80 to-white",
    iconWrap: "bg-violet-100 text-violet-600",
    icon: (
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V6m0 12v-2m9-4a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
  {
    label: "No-shows",
    value: "4.2%",
    change: "-8% vs last week",
    changeClassName: "text-emerald-700 bg-emerald-50",
    cardClassName: "border-amber-100 bg-gradient-to-br from-amber-50/70 to-white",
    iconWrap: "bg-amber-100 text-amber-600",
    icon: (
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M5.07 19h13.86a2 2 0 001.74-3L13.74 5a2 2 0 00-3.48 0L3.33 16a2 2 0 001.74 3z" />
      </svg>
    ),
  },
  {
    label: "Avg. lead time",
    value: "2.4 days",
    change: "Stable booking pace",
    changeClassName: "text-indigo-700 bg-indigo-50",
    cardClassName: "border-cyan-100 bg-gradient-to-br from-cyan-50/70 to-white",
    iconWrap: "bg-cyan-100 text-cyan-600",
    icon: (
      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
];

export default function FeaturesPage() {
  return (
    <>
        {/* Hero */}
        <section className="relative overflow-hidden py-14 sm:py-20">
            <div className="absolute inset-0 -z-10">
            <div className="absolute bottom-0 right-0 h-96 w-96 rounded-full bg-emerald-500/20 blur-3xl" />
            <div className="absolute top-1/3 left-1/2 h-80 w-80 -translate-x-1/3 -translate-y-1/2 rounded-full bg-indigo-600/30 blur-3xl" />
            </div>

            <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-2 lg:gap-14 lg:px-8">
                {/* left: Content */}
                <div className="space-y-6">
                    <Heading
                        badge="Product Features"
                        title="All your appointment operations,"
                        highlightText="beautifully automated."
                        description={`${APP_NAME} gives service businesses a unified system for online bookings, WhatsApp reminders, calendar sync, customer records, staff scheduling, and performance insights.`}
                        headingTag="h1"
                        titleClassName="text-3xl md:text-4xl lg:text-[50px] font-black text-neutral-900"
                    />

                    <div className="flex flex-col sm:flex-row gap-4">
                        <Link href={`${REGISTER_GOOGLE_URL}`} target="_blank" className="bg-indigo-600 text-white text-sm px-4 py-2.5 rounded-xl flex items-center justify-center gap-3">Start free workspace</Link>
                        <Link href={`${BASE_URL}/#pricing`} className="bg-gray-900 text-white text-sm px-4 py-2.5 rounded-xl flex items-center justify-center">View Pricing</Link>
                    </div>

                    <div className="flex flex-wrap gap-3 text-sm font-medium text-neutral-600">
                        {heroHighlights.map((item) => (
                        <span key={item} className="rounded-full border border-neutral-200 bg-white px-4 py-2">{item}</span>
                        ))}
                    </div>
                </div>
                {/* right: Dashboard preview */}
                <div className="relative animate-fade-in-scale">
                <div className="absolute right-0 top-6 z-20 hidden animate-float rounded-2xl bg-white p-4 shadow-sm md:block">
                    <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden>
                        <path d="m5 12 4 4L19 6" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                    </div>
                    <div>
                        <div className="text-sm uppercase">Reminder sent</div>
                        <div className="text-md font-bold text-emerald-600">WhatsApp • Delivered</div>
                    </div>
                    </div>
                </div>

                <div className="absolute left-2 bottom-14 z-20 hidden animate-float rounded-2xl bg-white px-4 py-3 shadow-sm md:block [animation-delay:1.5s]">
                    <div className="flex items-center gap-2">
                    <span className="relative flex h-2.5 w-2.5">
                        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
                    </span>
                    <div className="text-sm font-semibold text-neutral-800">Google Calendar synced</div>
                    </div>
                </div>

                <div className="relative overflow-hidden rounded-2xl border border-neutral-200/80 bg-white shadow-2xl">
                    <div className="relative z-10 border-b border-neutral-200 flex items-center justify-between px-3 py-4">
                    <div className="flex items-center gap-2 sm:gap-3">
                        <div className="relative">
                        <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-red-500 animate-pulse"></div>
                        <div className="absolute inset-0 w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-red-400 animate-ping"></div>
                        </div>
                        <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-yellow-400"></div>
                        <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-green-600"></div>
                    </div>
                    <div className="text-sm font-medium text-neutral-700">app.getsettime.com</div>
                    <div className="flex items-center gap-1.5 sm:gap-2">
                        <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-green-600 animate-pulse"></div>
                        <span className="text-[10px] sm:text-xs font-medium text-neutral-700">LIVE</span>
                    </div>
                    </div>

                    <div className="relative p-2 sm:p-3">
                    <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
                        <div>
                        <div className="text-xl font-bold text-neutral-900 sm:text-2xl">Today&apos;s overview</div>
                        </div>
                        <span className="rounded-xl border border-neutral-200 bg-white px-3 py-1.5 text-xs font-medium text-neutral-600">
                        Wed, 3 Jun 2026
                        </span>
                    </div>

                    <div className="mb-4 grid grid-cols-3 gap-2 sm:gap-3">
                        {[
                        { label: "Bookings", value: "84", accent: "text-indigo-600", bg: "bg-indigo-50 border-indigo-100" },
                        { label: "Confirmed", value: "71", accent: "text-emerald-600", bg: "bg-emerald-50 border-emerald-100" },
                        { label: "Revenue", value: "₹48K", accent: "text-violet-600", bg: "bg-violet-50 border-violet-100" },
                        ].map((stat) => (
                        <div key={stat.label} className={`rounded-xl border p-3 sm:p-4 ${stat.bg}`}>
                            <div className="text-xs font-semibold uppercase">{stat.label}</div>
                            <div className={`mt-0.5 text-xl font-bold sm:text-2xl ${stat.accent}`}>{stat.value}</div>
                        </div>
                        ))}
                    </div>

                    <div className="rounded-xl border border-neutral-100 bg-white p-4 shadow-sm">
                        <div className="mb-4 flex items-center justify-between gap-2">
                        <div>
                            <div className="text-xl font-bold leading-tight text-neutral-900">Schedule</div>
                            <div className="font-medium text-neutral-600">Provider availability</div>
                        </div>
                        <div className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow-sm shadow-indigo-200">+ New booking</div>
                        </div>

                        <div className="space-y-2.5">
                        {schedule.map((item) => (
                            <div
                            key={item.time}
                            className={`flex items-center gap-3 rounded-xl border p-3 transition hover:shadow-md ${
                                item.tone === "indigo"
                                ? "border-indigo-100 bg-indigo-50/60"
                                : item.tone === "emerald"
                                    ? "border-emerald-100 bg-emerald-50/60"
                                    : "border-neutral-100 bg-neutral-50"
                            }`}
                            >
                            <div className="flex h-10 w-14 shrink-0 flex-col items-center justify-center rounded-lg bg-white text-center shadow-sm ring-1 ring-neutral-100">
                                <span className="text-[10px] font-medium uppercase text-neutral-400">{item.period}</span>
                                <span className="text-sm font-bold text-neutral-800">{item.time}</span>
                            </div>
                            <div className="min-w-0 flex-1">
                                <div className="font-semibold text-neutral-800">{item.title}</div>
                                <div className="text-neutral-700 text-sm">{item.meta}</div>
                            </div>
                            <span
                                className={`shrink-0 rounded-full px-2.5 py-1 text-[10px] font-semibold sm:text-xs ${
                                item.status === "Confirmed"
                                    ? "bg-indigo-100 text-indigo-700"
                                    : item.status === "Paid"
                                    ? "bg-emerald-100 text-emerald-700"
                                    : "bg-neutral-200 text-neutral-700"
                                }`}
                            >
                                {item.status}
                            </span>
                            </div>
                        ))}
                        </div>
                    </div>

                    <div className="mt-3 grid grid-cols-2 gap-2 sm:gap-3">
                        <div className="flex items-center gap-3 rounded-xl border border-emerald-100 bg-emerald-50/60 p-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-600 text-white">
                            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                            </svg>
                        </div>
                        <div>
                            <div className="text-xs text-neutral-500">WhatsApp automation</div>
                            <div className="font-bold text-neutral-900">128 sent today</div>
                        </div>
                        </div>
                        <div className="flex items-center gap-3 rounded-xl border border-indigo-100 bg-indigo-50/60 p-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-600 shadow-sm ring-1 ring-neutral-100">
                            <svg className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                        </div>
                        <div>
                            <div className="text-xs text-neutral-500">Calendar sync</div>
                            <div className="font-bold text-neutral-900">Active • 2-way</div>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </section>
        
        {/* Trusted at Scale */}
        <section className="relative overflow-hidden bg-neutral-50 py-14 sm:py-20">
            <div className="relative mx-auto max-w-7xl px-4">
            <div className="mb-10 text-center">
                <Heading
                    badge="Trusted at scale"
                    title="Numbers that reflect real scheduling volume"
                />
            </div>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {[
                {
                    value: "50K+",
                    label: "Active users",
                    detail: "Clinics, salons & service teams",
                    icon: (
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    ),
                    iconBg: "bg-indigo-100 text-indigo-600",
                    valueColor: "text-indigo-600",
                    border: "border-indigo-100 hover:border-indigo-200",
                },
                {
                    value: "2M+",
                    label: "Appointments handled",
                    detail: "Booked through GetSetTime",
                    icon: (
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    ),
                    iconBg: "bg-violet-100 text-violet-600",
                    valueColor: "text-violet-600",
                    border: "border-violet-100 hover:border-violet-200",
                },
                {
                    value: "24/7",
                    label: "Self-service booking",
                    detail: "Clients book anytime online",
                    icon: (
                    <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    ),
                    iconBg: "bg-emerald-100 text-emerald-600",
                    valueColor: "text-emerald-600",
                    border: "border-emerald-100 hover:border-emerald-200",
                },
                {
                    value: "Auto",
                    label: "WhatsApp reminders",
                    detail: "Confirmations & follow-ups",
                    icon: (
                        <svg viewBox="0 0 16 16" className="h-6 w-6" fill="currentColor"><g id="SVGRepo_bgCarrier" strokeWidth="0"></g><g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M11.42 9.49c-.19-.09-1.1-.54-1.27-.61s-.29-.09-.42.1-.48.6-.59.73-.21.14-.4 0a5.13 5.13 0 0 1-1.49-.92 5.25 5.25 0 0 1-1-1.29c-.11-.18 0-.28.08-.38s.18-.21.28-.32a1.39 1.39 0 0 0 .18-.31.38.38 0 0 0 0-.33c0-.09-.42-1-.58-1.37s-.3-.32-.41-.32h-.4a.72.72 0 0 0-.5.23 2.1 2.1 0 0 0-.65 1.55A3.59 3.59 0 0 0 5 8.2 8.32 8.32 0 0 0 8.19 11c.44.19.78.3 1.05.39a2.53 2.53 0 0 0 1.17.07 1.93 1.93 0 0 0 1.26-.88 1.67 1.67 0 0 0 .11-.88c-.05-.07-.17-.12-.36-.21z"></path><path d="M13.29 2.68A7.36 7.36 0 0 0 8 .5a7.44 7.44 0 0 0-6.41 11.15l-1 3.85 3.94-1a7.4 7.4 0 0 0 3.55.9H8a7.44 7.44 0 0 0 5.29-12.72zM8 14.12a6.12 6.12 0 0 1-3.15-.87l-.22-.13-2.34.61.62-2.28-.14-.23a6.18 6.18 0 0 1 9.6-7.65 6.12 6.12 0 0 1 1.81 4.37A6.19 6.19 0 0 1 8 14.12z"></path></g></svg>
                    ),
                    iconBg: "bg-green-100 text-green-600",
                    valueColor: "text-green-600",
                    border: "border-green-100 hover:border-green-200",
                },
                ].map((stat) => (
                <div key={stat.label} className={`group rounded-2xl border bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-lg ${stat.border}`}>
                    <div className={`mb-4 flex h-12 w-12 items-center justify-center rounded-xl ${stat.iconBg} transition group-hover:scale-105`}>{stat.icon}</div>
                    <p className={`text-3xl font-bold tracking-tight ${stat.valueColor}`}>{stat.value}</p>
                    <p className="mt-1 font-semibold text-neutral-900">{stat.label}</p>
                    <p className="mt-1 text-sm text-neutral-500">{stat.detail}</p>
                </div>
                ))}
            </div>
            </div>
        </section>

        {/* Feature suite */}
        <section className="relative py-20">
            <div className="mx-auto max-w-7xl px-4">
                <div className="mb-10 text-center">
                    <Heading
                        badge="Feature suite"
                        title="Built for the real workflow of service businesses."
                        description="From the first booking request to follow-up reminders, GetSetTime keeps your team, customers and calendars synchronized in one professional operating layer."
                    />
                </div>

                <div className="mt-12 grid gap-5 lg:grid-cols-3">
                  {featureSuiteCards.map((card) => (
                    <Card
                      key={card.title}
                      badge={card.badge}
                      title={card.title}
                      description={card.description}
                      bullets={card.bullets}
                      iconNode={card.icon}
                      iconWrapperClassName={card.iconWrapperClassName}
                    />
                  ))}
                </div>
            </div>
        </section>

        {/* Automation journey */}
        <section className="relative overflow-hidden bg-[#f5f7ff] py-16 sm:py-24">
          <div className="absolute inset-0 -z-10">
            <div className="absolute left-[-120px] top-[-120px] h-80 w-80 rounded-full bg-indigo-200/40 blur-3xl" />
            <div className="absolute right-[-80px] top-20 h-72 w-72 rounded-full bg-violet-200/40 blur-3xl" />
            <div className="absolute bottom-[-120px] left-1/3 h-80 w-80 rounded-full bg-emerald-300/20 blur-3xl" />
            <div
              className="absolute inset-0 opacity-[0.35]"
              style={{
                backgroundImage:
                  "linear-gradient(to right, rgba(99,102,241,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(99,102,241,0.06) 1px, transparent 1px)",
                backgroundSize: "48px 48px",
              }}
            />
          </div>

          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-start lg:gap-10">
              <div className="lg:col-span-5 lg:sticky lg:top-24">
                <Heading
                  badge="Automation journey"
                  title="A complete appointment workflow that runs without chaos."
                  description={`Let customers book online while ${APP_NAME} handles confirmations, reminders, calendar updates, internal visibility and post-visit communication.`}
                  wrapperClassName="space-y-3"
                />
                <div className="mt-8 grid grid-cols-2 gap-3">
                  <div className="rounded-2xl border border-indigo-100 bg-white/80 p-4 shadow-sm backdrop-blur">
                    <div className="text-3xl font-bold text-indigo-600">4</div>
                    <p className="text-sm text-neutral-600">Automated stages</p>
                  </div>
                  <div className="rounded-2xl border border-emerald-100 bg-white/80 p-4 shadow-sm backdrop-blur">
                    <div className="text-3xl font-bold text-emerald-600">2</div>
                    <p className="text-sm text-neutral-600">Manual follow-ups</p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-7">
                <div className="relative space-y-4">
                  <div className="absolute left-[1.65rem] top-6 bottom-6 hidden w-px bg-gradient-to-b from-indigo-300 via-violet-300 to-emerald-300 sm:block" aria-hidden />

                  {workflowSteps.map((item) => (
                    <article key={item.title} className="group relative overflow-hidden rounded-2xl border border-white/80 bg-white/90 p-5 shadow-md shadow-indigo-100/20 backdrop-blur-sm transition duration-300 hover:-translate-y-0.5 hover:border-indigo-200 hover:shadow-xl sm:p-6">
                      <div className={`absolute inset-y-0 left-0 w-1 ${item.accentBar}`} aria-hidden />
                      <span className="pointer-events-none absolute right-1 top-0 select-none text-7xl font-black leading-none text-indigo-50 transition group-hover:text-indigo-100/80">{item.step}</span>

                      <div className="relative flex gap-4 sm:gap-5">
                        <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${item.iconWrap}`}>
                          {item.icon}
                        </div>
                        <div className="min-w-0 flex-1 pt-0.5">
                          <span className="inline-flex rounded-full bg-indigo-50 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-widest text-indigo-600">
                            Step {item.step} · {item.tag}
                          </span>
                          <h3 className="mt-2 text-lg font-bold text-neutral-900">{item.title}</h3>
                          <p className="mt-1.5 text-sm leading-relaxed text-neutral-600">{item.description}</p>
                        </div>
                      </div>
                    </article>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-16 overflow-hidden rounded-3xl border border-indigo-100/80 bg-white/70 p-6 shadow-xl shadow-indigo-100/30 backdrop-blur-sm">
              <div className="mb-10 text-center">
                <Heading
                    badge="By industry"
                    title="Built for how your business actually runs"
                    description="Tailored scheduling flows for clinics, salons, and growing service teams."
                />
              </div>

              <div className="grid gap-5 md:grid-cols-3 md:items-stretch">
                {industryCards.map((card) => (
                  <Link key={card.title} href={card.href} className={`group relative flex flex-col overflow-hidden rounded-2xl border bg-white p-6 transition duration-300 hover:-translate-y-1 hover:shadow-xl ${
                      card.featured
                        ? "border-indigo-200 shadow-lg ring-2 ring-indigo-100 md:-translate-y-2"
                        : "border-neutral-200 shadow-sm hover:border-indigo-200"
                    }`}
                  >
                    <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${card.gradient}`} aria-hidden />
                    <div className="relative">
                      <div className="mb-5 flex items-start justify-between gap-3">
                        <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${card.iconWrap}`}>
                          {card.icon}
                        </div>
                        <span className="rounded-md bg-neutral-100 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-neutral-500 group-hover:bg-indigo-50 group-hover:text-indigo-600">{card.badge}</span>
                      </div>
                      <h3 className="text-xl font-bold text-neutral-900">{card.title}</h3>
                      <p className="mt-2 flex-1 text-sm leading-relaxed text-neutral-600">{card.description}</p>
                      <span className="mt-5 inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 transition group-hover:gap-2">
                        View solution
                        <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                        </svg>
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Control center */}
        <section className="relative overflow-hidden py-16 sm:py-24">
          <div className="absolute inset-0 -z-10 bg-gradient-to-b from-white via-indigo-50/30 to-white" />
          <div className="absolute right-0 top-1/4 h-72 w-72 rounded-full bg-violet-200/30 blur-3xl" />

          <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-center lg:gap-10">
                <div className="lg:col-span-5">
                    <Heading
                    badge="Control center"
                    title="Know what is happening across every appointment."
                    description="Measure appointment volume, revenue, service demand, staff performance, reminder delivery and customer trends from a clean analytics layer."
                    />
                    <CheckList
                    items={[
                        "Live booking volume & revenue trends",
                        "No-show and reminder delivery rates",
                        "Staff utilization and open capacity",
                        "Service-level demand breakdown",
                    ]}
                    gridClassName="mt-6 space-y-2"
                    />
                </div>

                <div className="lg:col-span-7 relative">
                  <div className=" rounded-2xl overflow-hidden border border-neutral-200/80 bg-white shadow-2xl shadow-indigo-100/40">

                    <div className="bg-gradient-to-br from-indigo-50/50 via-white to-violet-50/30 p-4">
                        <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
                            <div>
                            <p className="text-xs font-semibold uppercase tracking-widest text-indigo-600">Weekly performance</p>
                            <h3 className="text-xl font-bold text-neutral-900 sm:text-2xl">Total bookings trend</h3>
                            <div className="mt-3 flex flex-wrap items-baseline gap-3">
                                <p className="text-4xl font-bold tracking-tight text-neutral-900">{bookingChart.total}</p>
                                <span className="text-sm text-neutral-500">bookings this week</span>
                                <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-700">+18% vs last week</span>
                            </div>
                            </div>
                            <div className="inline-flex rounded-xl border border-neutral-200 bg-white p-1 text-xs font-semibold shadow-sm">
                            <span className="rounded-lg bg-indigo-600 px-3 py-1.5 text-white">Week</span>
                            <span className="px-3 py-1.5 text-neutral-500">Month</span>
                            </div>
                        </div>

                        <div className="relative rounded-2xl border border-indigo-100/80 bg-white p-4 shadow-sm sm:p-5">
                            <div className="mb-3 flex items-center justify-between gap-2">
                                <p className="text-sm font-medium text-neutral-700">Daily booking volume</p>
                                <div className="flex items-center gap-2 text-xs text-neutral-500">
                                    <span className="inline-flex items-center gap-1.5">
                                        <span className="h-2 w-6 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500" />
                                        Total bookings
                                    </span>
                                    <span className="hidden sm:inline-flex items-center gap-1.5">
                                        <span className="h-2 w-2 rounded-full bg-indigo-600" />
                                        Peak day
                                    </span>
                                </div>
                            </div>

                            <svg viewBox={`0 0 ${bookingChart.width} ${bookingChart.height}`} className="h-auto w-full" role="img" aria-label={`Weekly total bookings line chart showing ${bookingChart.total} appointments`}>
                            <defs>
                                <linearGradient id="bookingAreaFill" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#6366f1" stopOpacity="0.35" />
                                <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.02" />
                                </linearGradient>
                                <linearGradient id="bookingLineStroke" x1="0" y1="0" x2="1" y2="0">
                                <stop offset="0%" stopColor="#4f46e5" />
                                <stop offset="100%" stopColor="#7c3aed" />
                                </linearGradient>
                            </defs>

                            {bookingChart.yTicks.map((tick) => (
                                <g key={tick.label}>
                                <line
                                    x1={bookingChart.pad.left}
                                    y1={tick.y}
                                    x2={bookingChart.width - bookingChart.pad.right}
                                    y2={tick.y}
                                    stroke="#e5e7eb"
                                    strokeDasharray="4 4"
                                />
                                <text x={8} y={tick.y + 4} className="fill-neutral-400 text-[10px]">
                                    {tick.label}
                                </text>
                                </g>
                            ))}

                            <path d={bookingChart.areaPath} fill="url(#bookingAreaFill)" />
                            <path
                                d={bookingChart.linePath}
                                fill="none"
                                stroke="url(#bookingLineStroke)"
                                strokeWidth="3"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                            />

                            {bookingChart.points.map((point) => (
                                <g key={point.day}>
                                <circle
                                    cx={point.x}
                                    cy={point.y}
                                    r={point.bookings === bookingChart.max ? 6 : 4.5}
                                    fill={point.bookings === bookingChart.max ? "#4f46e5" : "#ffffff"}
                                    stroke="#4f46e5"
                                    strokeWidth="2.5"
                                />
                                <text
                                    x={point.x}
                                    y={point.y - 12}
                                    textAnchor="middle"
                                    className="fill-indigo-700 text-[10px] font-semibold"
                                >
                                    {point.bookings}
                                </text>
                                <text
                                    x={point.x}
                                    y={bookingChart.height - 10}
                                    textAnchor="middle"
                                    className="fill-neutral-500 text-[11px] font-medium"
                                >
                                    {point.day}
                                </text>
                                </g>
                            ))}
                            </svg>

                            <div className="mt-4 grid grid-cols-7 gap-1 border-t border-neutral-100 pt-4">
                            {weeklyBookings.map((d) => {
                                const pct = Math.round((d.bookings / bookingChart.max) * 100);
                                return (
                                <div key={d.day} className="text-center">
                                    <div className="mx-auto h-1.5 w-full max-w-[2.5rem] overflow-hidden rounded-full bg-indigo-100">
                                    <div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500" style={{ width: `${pct}%` }} />
                                    </div>
                                </div>
                                );
                            })}
                            </div>
                        </div>
                    
                        <div className="mt-4 grid gap-3 sm:grid-cols-3">
                          {analyticsMetrics.map((metric) => (
                            <div key={metric.label} className={`group relative overflow-hidden rounded-2xl border p-4 shadow-sm transition duration-300 hover:-translate-y-0.5 hover:shadow-md ${metric.cardClassName}`} >
                              <div className="flex items-start justify-between gap-3">
                                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${metric.iconWrap}`}>
                                  {metric.icon}
                                </div>
                                <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${metric.changeClassName}`}>
                                  {metric.change}
                                </span>
                              </div>
                              <p className="mt-4 text-xs font-semibold uppercase tracking-wider text-neutral-500">{metric.label}</p>
                              <p className="mt-1 text-2xl font-bold tracking-tight text-neutral-900">{metric.value}</p>
                            </div>
                          ))}
                        </div>

                        <div className="absolute left-2 bottom-20 z-2 hidden lg:block rounded-xl bg-white px-4 py-4 shadow-sm animate-float rounded-2xl border border-emerald-100 bg-gradient-to-br from-emerald-50 to-white p-5 shadow-sm">
                          <div className="flex items-center justify-between gap-2">
                            <p className="text-sm text-neutral-500">Reminder delivery</p>
                            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                              </svg>
                            </span>
                          </div>
                          <p className="mt-2 text-3xl font-bold text-neutral-900">96.8%</p>
                          <div className="mt-3 h-2 overflow-hidden rounded-full bg-emerald-100">
                            <div className="h-full w-[96.8%] rounded-full bg-gradient-to-r from-emerald-500 to-green-500" />
                          </div>
                        </div>

                        <div className="absolute right-2 top-0 z-2 hidden lg:block rounded-xl bg-white px-4 py-4 shadow-sm animate-float  rounded-2xl border border-indigo-100 bg-gradient-to-br from-indigo-50 to-white p-5 shadow-sm">
                          <div className="flex items-center justify-between">
                            <p className="text-sm text-neutral-500">Peak booking day</p>
                            <span className="rounded-full bg-indigo-100 px-2 py-0.5 text-xs font-semibold text-indigo-700">Saturday</span>
                          </div>
                          <p className="mt-2 text-3xl font-bold text-neutral-900">{bookingChart.max}</p>
                          <p className="mt-1 text-xs text-neutral-500">highest single-day volume this week</p>
                          <div className="mt-4 flex gap-2">
                            <span className="rounded-lg bg-white px-2.5 py-1 text-xs font-medium text-neutral-600 ring-1 ring-neutral-100">6 providers</span>
                            <span className="rounded-lg bg-white px-2.5 py-1 text-xs font-medium text-neutral-600 ring-1 ring-neutral-100">38 open slots</span>
                          </div>
                        </div>

                    </div>
                  </div>
                </div>
            </div>
          </div>
        </section>

        {/* Launch offer */}
        <section className="relative py-16 sm:py-24">
            <div className="absolute w-full inset-0 bg-gradient-to-br from-transparent via-indigo-400/20 to-transparent pointer-events-none"></div>
            <div className="relative z-10 mx-auto max-w-7xl px-4">

              <div className="relative grid gap-10 lg:grid-cols-2 lg:items-center">
                <div>
                  <Heading
                    badge="Launch offer"
                    title="Start free with 250 appointments every month."
                    description="Every workspace gets free monthly booking volume. Upgrade only when your team needs more seats, providers, locations or advanced automation."
                  />
                  <CheckList
                    items={[
                      "Online booking & branded pages",
                      "WhatsApp & email reminders",
                      "Google Calendar two-way sync",
                      "Staff, services & reporting",
                    ]}
                    gridClassName="mt-6 space-y-2"
                  />
                </div>

                <div className="relative">
                  <div className="absolute -inset-1 rounded-[1.75rem] bg-gradient-to-br from-white/40 to-cyan-200/30 blur-sm" />
                  <div className="relative overflow-hidden rounded-[1.65rem] bg-white p-6 shadow-2xl sm:p-8">
                    <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-indigo-100/60" aria-hidden />

                    <div className="relative flex flex-wrap items-start justify-between gap-4">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-widest text-indigo-600">Starter plan</p>
                        <div className="mt-2 flex items-end gap-1">
                          <span className="text-5xl font-bold tracking-tight text-neutral-900">₹999</span>
                          <span className="pb-2 text-sm font-medium text-neutral-500">/month</span>
                        </div>
                        <p className="mt-1 text-xs text-neutral-500">+ 18% GST · billed monthly</p>
                      </div>
                      <span className="rounded-full bg-indigo-600 px-3 py-1.5 text-xs font-semibold text-white shadow-md shadow-indigo-200">
                        Popular
                      </span>
                    </div>

                    <div className="relative mt-5 rounded-2xl bg-blue-50 p-4 ring-1 ring-blue-100">
                      <p className="text-sm font-bold text-blue-700">1 seat included</p>
                      <p className="mt-1 text-xs text-blue-600">First 250 bookings/month included</p>
                    </div>

                    <ul className="relative mt-6 space-y-3">
                      {[
                        "Public booking page",
                        "Staff & service setup",
                        "Email notifications",
                        "Booking dashboard",
                      ].map((item) => (
                        <li key={item} className="flex items-center gap-3 text-sm font-medium text-neutral-700">
                          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-indigo-100 text-indigo-600">
                            <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden>
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                            </svg>
                          </span>
                          {item}
                        </li>
                      ))}
                    </ul>

                    <div className="relative mt-8 space-y-3">
                      <Link
                        href={REGISTER_GOOGLE_URL}
                        target="_blank"
                        className="flex w-full items-center justify-center rounded-xl bg-indigo-600 px-6 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-200 transition hover:bg-indigo-700"
                      >
                        Get started
                      </Link>
                      <Link
                        href={`${BASE_URL}/#pricing`}
                        className="flex w-full items-center justify-center rounded-xl border border-neutral-200 bg-neutral-50 px-6 py-3 text-sm font-semibold text-neutral-800 transition hover:border-indigo-200 hover:bg-indigo-50 hover:text-indigo-700"
                      >
                        Compare all plans
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            
            </div>
        </section>
    </>
  );
}
